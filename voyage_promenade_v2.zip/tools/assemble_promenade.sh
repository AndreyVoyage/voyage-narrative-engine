#!/bin/bash
# Voyage Promenade v2.0 — Скрипт сборки промпта
# Использование: bash assemble_promenade.sh [имя_героини]

HEROINE_NAME=${1:-"Анна"}
OUTPUT="full_prompt_promenade.txt"
REPO_DIR="\${HOME}/voyage-narrative-engine"

echo "[1/5] Загрузка CORE..."
cat "\${REPO_DIR}/core/VOYAGE_NARRATIVE_CORE_v2.md" > "\${OUTPUT}"
echo "" >> "\${OUTPUT}"

echo "[2/5] Загрузка персонажей..."
cat "\${REPO_DIR}/personas/SERGEY_MODULE_v3.json" >> "\${OUTPUT}"
echo "" >> "\${OUTPUT}"
cat "\${REPO_DIR}/personas/MAXIM_MODULE_v1.json" >> "\${OUTPUT}"
echo "" >> "\${OUTPUT}"
cat "\${REPO_DIR}/personas/FEMALE_USER_MODULE.json" >> "\${OUTPUT}"
echo "" >> "\${OUTPUT}"

echo "[3/5] Загрузка сценария..."
cat "\${REPO_DIR}/scenarios/SCENARIO_PROMENADE_v2.md" >> "\${OUTPUT}"
echo "" >> "\${OUTPUT}"

echo "[4/5] Загрузка STATE..."
cat "\${REPO_DIR}/state/STATE_TEMPLATE_PROMENADE.json" >> "\${OUTPUT}"
echo "" >> "\${OUTPUT}"

echo "[5/5] Подстановка имени героини..."
sed -i "s/{{HEROINE_NAME}}/\${HEROINE_NAME}/g" "\${OUTPUT}"

echo "✅ Готово: \${OUTPUT}"
echo "Имя героини: \${HEROINE_NAME}"
echo "Размер: $(wc -c < \${OUTPUT}) байт"