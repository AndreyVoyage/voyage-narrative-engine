#!/bin/bash
# ============================================================
# Voyage Sauna Kira-Marina Package — Termux Setup
# ============================================================

set -e

REPO_DIR="${1:-$HOME/voyage-narrative-engine}"
ARCHIVE_NAME="voyage_sauna_km_package.zip"
TMP_DIR="$HOME/tmp_sauna_km_$$"

echo "========================================"
echo "  Voyage Sauna Kira-Marina — Setup"
echo "========================================"
echo ""

# 1. Проверка репозитория
if [ ! -d "$REPO_DIR/.git" ]; then
    echo "❌ Git-репозиторий не найден в: $REPO_DIR"
    exit 1
fi

cd "$REPO_DIR"
echo "📁 Репозиторий: $(pwd)"

# 2. Поиск архива
ARCHIVE_PATH=""
for path in "$REPO_DIR/$ARCHIVE_NAME" "$HOME/$ARCHIVE_NAME" "$HOME/Downloads/$ARCHIVE_NAME" "$HOME/storage/downloads/$ARCHIVE_NAME"; do
    if [ -f "$path" ]; then
        ARCHIVE_PATH="$path"
        break
    fi
done

if [ -z "$ARCHIVE_PATH" ]; then
    echo "❌ Архив $ARCHIVE_NAME не найден."
    exit 1
fi

echo "📦 Архив найден: $ARCHIVE_PATH"

# 3. Git pull
echo ""
echo "[1/6] Git pull..."
git pull origin main 2>/dev/null || git pull origin master 2>/dev/null || echo "⚠️ Pull пропущен"

# 4. Распаковка
echo ""
echo "[2/6] Распаковка..."
mkdir -p "$TMP_DIR"
unzip -q "$ARCHIVE_PATH" -d "$TMP_DIR"
echo "✅ Распаковано"

# 5. Backup
echo ""
echo "[3/6] Backup..."
BACKUP_DIR="$REPO_DIR/.backup_sauna_km_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
for file in state/STATE_TEMPLATE.json scenarios/SCENARIO_MATRIX.json; do
    [ -f "$REPO_DIR/$file" ] && cp "$REPO_DIR/$file" "$BACKUP_DIR/" && echo "💾 $file"
done

# 6. Копирование
echo ""
echo "[4/6] Копирование..."
cp "$TMP_DIR/SCENARIO_SAUNA_KIRA_MARINA_v1.md" "$REPO_DIR/scenarios/"
cp "$TMP_DIR/STATE_TEMPLATE.json" "$REPO_DIR/state/"
cp "$TMP_DIR/SCENARIO_MATRIX.json" "$REPO_DIR/scenarios/"
cp "$TMP_DIR/GOVERNANCE_NOTE_SAUNA_KM.md" "$REPO_DIR/governance/"
echo "✅ Файлы скопированы"

# 7. Валидация JSON
echo ""
echo "[5/6] Валидация JSON..."
python3 -c "
import json, sys
files = [
    ('$REPO_DIR/state/STATE_TEMPLATE.json', 'STATE_TEMPLATE'),
    ('$REPO_DIR/scenarios/SCENARIO_MATRIX.json', 'SCENARIO_MATRIX')
]
for path, name in files:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            json.load(f)
        print(f'   ✅ {name}')
    except Exception as e:
        print(f'   ❌ {name}: {e}')
        sys.exit(1)
"

# 8. Git commit + push
echo ""
echo "[6/6] Git commit..."
git add -A
git status --short
echo ""
read -p "Подтвердите коммит? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    echo "❌ Коммит отменён."
    rm -rf "$TMP_DIR"
    exit 0
fi

git commit -m "feat: add sauna Kira-Marina scenario (SC_SAUNA_KM_001) — 5x5 variations

- Add SCENARIO_SAUNA_KIRA_MARINA_v1.md (25 micro-scenes)
- Update STATE_TEMPLATE.json (55+ flags)
- Update SCENARIO_MATRIX.json (SC_SAUNA_KM_001)
- Add GOVERNANCE_NOTE_SAUNA_KM.md (AG2 safety rules)

Psychology: Basson, Cialdini, Greene, Attachment, Excitation Transfer, Perel

Safety: STOP words, [SAFETY_CHECK] at U6/MA6, aftercare mandatory"

echo "✅ Коммит создан"

echo ""
echo "Push..."
git push origin $(git branch --show-current) && echo "✅ Push выполнен" || echo "⚠️ Push не удался."

# Cleanup
rm -rf "$TMP_DIR"

echo ""
echo "========================================"
echo "  ✅ SETUP ЗАВЕРШЁН!"
echo "========================================"
echo ""
echo "📁 Backup: $BACKUP_DIR"
echo "🧠 Сценарий: SC_SAUNA_KM_001"
echo "📊 Вариантов: 25 (5×5)"
echo "🛡️ Safety: СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА"
echo ""
echo "========================================"
