# 🧖 Voyage Sauna Kira-Marina Package v1.0.0
> **Сценарий:** SC_SAUNA_KM_001 — «Сауна: Квартет Кира-Марина»
> **Режим:** AG2 (Пользователь активен)
> **Дата:** 2026-06-07

---

## 📦 Состав пакета

| Файл | Назначение |
|------|-----------|
| `SCENARIO_SAUNA_KIRA_MARINA_v1.md` | Полный сценарий: 5 сценариев × 5 вариантов = 25 микросцен |
| `STATE_TEMPLATE.json` | Обновлённый шаблон с 55+ флагами |
| `SCENARIO_MATRIX.json` | Регистрация SC_SAUNA_KM_001 |
| `GOVERNANCE_NOTE_SAUNA_KM.md` | Правила AG2, safety, breaking points |
| `README.md` | Этот файл |

---

## 🧠 Психологический фундамент

- **Basson** — Responsive Desire (обе женщины реагируют на стимулы)
- **Cialdini** — Social Proof, Scarcity, Reciprocity (две женщины = конкуренция)
- **Greene** — Mixed Signals, Triangles, Isolation (сауна = ловушка)
- **Attachment Theory** — Anxious (Кира) + Anxious-Preoccupied (Марина)
- **Excitation Transfer** — Жар сауны = ошибочная атрибуция влечения
- **Perel** — Distance Creates Desire (отстранение усиливает напряжение)

---

## 🚀 Быстрый старт

```bash
# 1. Распаковать архив
unzip voyage_sauna_km_package.zip -d voyage_sauna_km_package/

# 2. Запустить скрипт установки
cd voyage_sauna_km_package
chmod +x setup_sauna_km.sh
./setup_sauna_km.sh /path/to/voyage-narrative-engine

# 3. Готово!
```

---

## 🛡️ Безопасность

- **СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА** — мгновенный выход
- **[SAFETY_CHECK]** перед У6/MA6
- **Breaking Points:** осмеяние чувств, сравнение тела, форсирование интима
- **Aftercare:** обязателен после каждой сцены с высокой интенсивностью

---

## 📝 Лицензия

Этот пакет является частью Voyage Narrative Engine. Используйте в рамках проекта.

---

> *«Это не про секс в сауне. Это про то, как две женщины с тревожной привязанностью учатся быть желанными через зеркало друг друга.»*
