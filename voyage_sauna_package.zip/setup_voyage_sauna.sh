#!/bin/bash
# ============================================================
# Voyage Sauna Package — Setup Script
# Установщик пакета «Сауна: Дуэт обольстителей»
# ============================================================

set -e

PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="${1:-./voyage-narrative-engine}"

echo "========================================"
echo "  Voyage Sauna Package Installer"
echo "  v1.0.0 | 2026-06-07"
echo "========================================"
echo ""

# Проверка целевой директории
if [ ! -d "$TARGET_DIR" ]; then
    echo "❌ Целевая директория не найдена: $TARGET_DIR"
    echo "   Создаём..."
    mkdir -p "$TARGET_DIR"
fi

echo "📁 Целевая директория: $TARGET_DIR"
echo "📦 Пакет: $PACKAGE_DIR"
echo ""

# ============================================================
# 1. Копирование файлов
# ============================================================
echo "[1/5] Копирование файлов сценария..."

# Сценарий
cp "$PACKAGE_DIR/SCENARIO_SAUNA_DUO_SEDUCTION_v2.md" "$TARGET_DIR/scenarios/" 2>/dev/null || {
    mkdir -p "$TARGET_DIR/scenarios"
    cp "$PACKAGE_DIR/SCENARIO_SAUNA_DUO_SEDUCTION_v2.md" "$TARGET_DIR/scenarios/"
}

# Governance
cp "$PACKAGE_DIR/GOVERNANCE_NOTE.md" "$TARGET_DIR/governance/" 2>/dev/null || {
    mkdir -p "$TARGET_DIR/governance"
    cp "$PACKAGE_DIR/GOVERNANCE_NOTE.md" "$TARGET_DIR/governance/"
}

# State (backup старый)
if [ -f "$TARGET_DIR/state/STATE_TEMPLATE.json" ]; then
    echo "   💾 Backup старого STATE_TEMPLATE.json → STATE_TEMPLATE.json.bak"
    cp "$TARGET_DIR/state/STATE_TEMPLATE.json" "$TARGET_DIR/state/STATE_TEMPLATE.json.bak"
fi
cp "$PACKAGE_DIR/STATE_TEMPLATE.json" "$TARGET_DIR/state/" 2>/dev/null || {
    mkdir -p "$TARGET_DIR/state"
    cp "$PACKAGE_DIR/STATE_TEMPLATE.json" "$TARGET_DIR/state/"
}

# Scenario Matrix (backup старый)
if [ -f "$TARGET_DIR/scenarios/SCENARIO_MATRIX.json" ]; then
    echo "   💾 Backup старого SCENARIO_MATRIX.json → SCENARIO_MATRIX.json.bak"
    cp "$TARGET_DIR/scenarios/SCENARIO_MATRIX.json" "$TARGET_DIR/scenarios/SCENARIO_MATRIX.json.bak"
fi
cp "$PACKAGE_DIR/SCENARIO_MATRIX.json" "$TARGET_DIR/scenarios/" 2>/dev/null || {
    cp "$PACKAGE_DIR/SCENARIO_MATRIX.json" "$TARGET_DIR/scenarios/"
}

echo "   ✅ Файлы скопированы"
echo ""

# ============================================================
# 2. Валидация JSON
# ============================================================
echo "[2/5] Валидация JSON..."

python3 -c "
import json, sys
files = [
    '$TARGET_DIR/state/STATE_TEMPLATE.json',
    '$TARGET_DIR/scenarios/SCENARIO_MATRIX.json'
]
for f in files:
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            json.load(fh)
        print(f'   ✅ {f.split("/")[-1]} — валиден')
    except Exception as e:
        print(f'   ❌ {f.split("/")[-1]} — ОШИБКА: {e}')
        sys.exit(1)
" || {
    echo "❌ Валидация JSON не пройдена. Отмена."
    exit 1
}

echo ""

# ============================================================
# 3. Проверка структуры репозитория
# ============================================================
echo "[3/5] Проверка структуры репозитория..."

REQUIRED_DIRS=("core" "personas" "state" "scenarios" "memory" "visual" "governance" "living_world")
for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$TARGET_DIR/$dir" ]; then
        echo "   ✅ $dir/"
    else
        echo "   ⚠️  $dir/ — не найдена (создаём)"
        mkdir -p "$TARGET_DIR/$dir"
    fi
done

echo ""

# ============================================================
# 4. Интеграция с CORE.md
# ============================================================
echo "[4/5] Интеграция с CORE.md..."

CORE_FILE="$TARGET_DIR/core/VOYAGE_NARRATIVE_CORE.md"
if [ -f "$CORE_FILE" ]; then
    if grep -q "SC_SAUNA_DUO_001" "$CORE_FILE" 2>/dev/null; then
        echo "   ℹ️  Сценарий уже зарегистрирован в CORE.md"
    else
        echo "" >> "$CORE_FILE"
        echo "---" >> "$CORE_FILE"
        echo "" >> "$CORE_FILE"
        echo "> **SC_SAUNA_DUO_001** — зарегистрирован в SCENARIO_MATRIX.json" >> "$CORE_FILE"
        echo "> **Режим:** AG4 (NPC-to-NPC), Пользователь = AG0 (вуайерист)" >> "$CORE_FILE"
        echo "> **Файл:** scenarios/SCENARIO_SAUNA_DUO_SEDUCTION_v2.md" >> "$CORE_FILE"
        echo "> **Governance:** governance/GOVERNANCE_NOTE.md" >> "$CORE_FILE"
        echo "   ✅ Сценарий зарегистрирован в CORE.md"
    fi
else
    echo "   ⚠️  CORE.md не найден. Пропускаем интеграцию."
fi

echo ""

# ============================================================
# 5. Финальный отчёт
# ============================================================
echo "[5/5] Финальный отчёт..."
echo ""
echo "========================================"
echo "  ✅ Установка завершена!"
echo "========================================"
echo ""
echo "📋 Установленные файлы:"
echo "   • scenarios/SCENARIO_SAUNA_DUO_SEDUCTION_v2.md"
echo "   • governance/GOVERNANCE_NOTE.md"
echo "   • state/STATE_TEMPLATE.json"
echo "   • scenarios/SCENARIO_MATRIX.json"
echo ""
echo "🧠 Психологический аппарат:"
echo "   • Basson Responsive Desire"
echo "   • Cialdini 6 принципов убеждения"
echo "   • Greene Искусство обольщения"
echo "   • Birnbaum Туннельное зрение"
echo "   • NLP Якорение + Раппорт"
echo "   • Gottman Turning Toward"
echo "   • Attachment Theory (Anxious Escalation)"
echo "   • Perel Парадокс близости и желания"
echo "   • BDSM Subspace/Domspace/Aftercare"
echo "   • Excitation Transfer"
echo ""
echo "🛡️ Безопасность:"
echo "   • СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА = мгновенный выход"
echo "   • [SAFETY_CHECK] перед У6-пик"
echo "   • Aftercare обязателен (Акт VI)"
echo ""
echo "🚀 Для запуска:"
echo "   1. Загрузите STATE_TEMPLATE.json в сессию"
echo "   2. Активируйте SC_SAUNA_DUO_001"
echo "   3. Пользователь даёт команду и уходит (AG0)"
echo "   4. Сергей и Максим действуют автономно (AG4)"
echo ""
echo "========================================"
