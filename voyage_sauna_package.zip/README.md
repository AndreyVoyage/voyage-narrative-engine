# 🧖 Voyage Sauna Package v1.0.0
> **Сценарий:** «Сауна: Дуэт обольстителей» (SC_SAUNA_DUO_001)
> **Режим:** AG4 (NPC-to-NPC) + AG0 (Пользователь-вуайерист)
> **Дата:** 2026-06-07

---

## 📦 Состав пакета

| Файл | Назначение |
|------|-----------|
| `SCENARIO_SAUNA_DUO_SEDUCTION_v2.md` | Полный сценарий с ФМДР, 6 актами, психологическими аннотациями |
| `GOVERNANCE_NOTE.md` | Правила AG4, NPC-to-NPC логика, протокол вуайеризма, safety |
| `STATE_TEMPLATE.json` | Обновлённый шаблон состояния с 17 флагами сауны |
| `SCENARIO_MATRIX.json` | Обновлённая матрица с `SC_SAUNA_DUO_001` |
| `setup_voyage_sauna.sh` | Скрипт установки (backup, валидация, интеграция) |
| `README.md` | Этот файл |

---

## 🧠 Психологический фундамент

- **Basson** — Responsive Desire (круговая модель)
- **Cialdini** — Reciprocity, Scarcity, Social Proof, Authority
- **Greene** — Mixed Signals, Isolation, Triangles, Effect Regression
- **Birnbaum** — Cognitive Narrowing (туннельное зрение)
- **NLP** — Anchoring, Mirroring, Rapport
- **Gottman** — Turning Toward (closed dyad)
- **Bowlby/Ainsworth** — Attachment Theory (Anxious Escalation)
- **Perel** — Distance Creates Desire
- **BDSM** — Subspace / Domspace / Aftercare
- **Excitation Transfer** — Misattribution of Arousal

---

## 🚀 Быстрый старт

```bash
# 1. Распаковать архив
unzip voyage_sauna_package.zip

# 2. Запустить установку
./setup_voyage_sauna.sh /path/to/voyage-narrative-engine

# 3. Готово! Сценарий зарегистрирован.
```

---

## 🛡️ Безопасность

- **СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА** — мгновенный выход
- **[SAFETY_CHECK]** перед У6-пик
- **Aftercare обязателен** (Акт VI)
- **Breaking Point Максима** — если Кира использует его как объект, он уходит (М6)

---

## 📝 Лицензия

Этот пакет является частью Voyage Narrative Engine. Используйте в рамках проекта.

---

> *«Сауна — это не про манипуляцию. Это про то, как Кира, лишённая безопасной базы, учится находить целостность в хаосе.»*
