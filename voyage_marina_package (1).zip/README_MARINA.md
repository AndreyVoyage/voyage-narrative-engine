# ☀️ Voyage Marina Package v1.0.0
> **Персонаж:** Марина (MARINA_001) — подруга Киры, солнечный зайчик
> **Режим:** AG1-AG4 (активная / автономная)
> **Дата:** 2026-06-07

---

## 📦 Состав пакета

| Файл | Назначение |
|------|-----------|
| `MARINA_MODULE_v1.1.json` | Полный модуль персонажа (психология, speech, visuals, relationships) |
| `STATE_TEMPLATE.json` | Обновлённый шаблон с 20+ флагами Марины |
| `SCENARIO_MATRIX.json` | 8 сценариев с Мариной (001-007 + sauna) |
| `CORE_PATCH_MARINA.md` | Мнемоники МР, MA1-MA7, МГ1-МГ3, квинтет |
| `QWEN_ADAPTER_MARINA.md` | Визуальные промпты для генерации изображений Марины |
| `GOVERNANCE_NOTE_MARINA.md` | Правила безопасности, breaking points, динамики группы |
| `README_MARINA.md` | Этот файл |

---

## 🧠 Психологический фундамент

- **Erikson** — Identity vs Role Confusion → Intimacy vs Isolation (18 лет)
- **Bowlby/Ainsworth** — Anxious-Preoccupied attachment (не fearful-avoidant)
- **Simon & Gagnon** — Sexual Scripting Theory (cultural vs interpersonal script)
- **Festinger** — Social Comparison (с Кирой)
- **Basson** — Responsive Desire (интим требует 5-6 уровней)
- **Perel** — Distance Creates Desire (Сергей как недоступный объект)
- **NLP** — Mirroring, Future Pacing, Anchoring

---

## 🚀 Быстрый старт

```bash
# 1. Распаковать архив
unzip voyage_marina_package.zip -d voyage_marina_package/

# 2. Запустить скрипт установки
cd voyage_marina_package
chmod +x setup_marina.sh
./setup_marina.sh /path/to/voyage-narrative-engine

# 3. Готово! Марина интегрирована.
```

---

## 🛡️ Безопасность

- **СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА** — мгновенный выход
- **[SAFETY_CHECK]** перед MA3 и MA6
- **Breaking Points:** осмеяние чувств, сравнение тела с Кирой, форсирование интима
- **Aftercare:** после MA3 (1-2 абзаца), после MA6 (2-3 абзаца)

---

## 📝 Лицензия

Этот пакет является частью Voyage Narrative Engine. Используйте в рамках проекта.

---

> *«Марина — не просто солнечный зайчик. Она — зеркало, в котором Кира видит альтернативу. Она — катализатор, который ускоряет или ломает. Она — уязвимость, спрятанная за смехом.»*
