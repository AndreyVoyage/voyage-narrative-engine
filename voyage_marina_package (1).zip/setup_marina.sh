#!/bin/bash
# ============================================================
# Voyage Marina Package — Termux Setup Script
# Распаковка + копирование + git commit + push
# ============================================================

set -e

REPO_DIR="${1:-$HOME/voyage-narrative-engine}"
ARCHIVE_NAME="voyage_marina_package.zip"
TMP_DIR="$HOME/tmp_marina_$$"

echo "========================================"
echo "  Voyage Marina Package — Setup"
echo "========================================"
echo ""

# 1. Проверка репозитория
if [ ! -d "$REPO_DIR/.git" ]; then
    echo "❌ Git-репозиторий не найден в: $REPO_DIR"
    echo "   Укажите путь: ./setup_marina.sh /path/to/repo"
    exit 1
fi

cd "$REPO_DIR"
echo "📁 Репозиторий: $(pwd)"

# 2. Поиск архива
ARCHIVE_PATH=""
for path in "$REPO_DIR/$ARCHIVE_NAME" "$HOME/$ARCHIVE_NAME" "$HOME/Downloads/$ARCHIVE_NAME" "$HOME/storage/downloads/$ARCHIVE_NAME"; do
    if [ -f "$path" ]; then
        ARCHIVE_PATH="$path"
        break
    fi
done

if [ -z "$ARCHIVE_PATH" ]; then
    echo "❌ Архив $ARCHIVE_NAME не найден."
    echo "   Скопируйте архив в репозиторий и запустите снова."
    exit 1
fi

echo "📦 Архив найден: $ARCHIVE_PATH"

# 3. Git pull
echo ""
echo "[1/6] Git pull..."
git pull origin main 2>/dev/null || git pull origin master 2>/dev/null || echo "⚠️ Pull пропущен"

# 4. Распаковка
echo ""
echo "[2/6] Распаковка..."
mkdir -p "$TMP_DIR"
unzip -q "$ARCHIVE_PATH" -d "$TMP_DIR"
echo "✅ Распаковано в $TMP_DIR"

# 5. Backup старых файлов
echo ""
echo "[3/6] Backup..."
BACKUP_DIR="$REPO_DIR/.backup_marina_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
for file in state/STATE_TEMPLATE.json scenarios/SCENARIO_MATRIX.json; do
    [ -f "$REPO_DIR/$file" ] && cp "$REPO_DIR/$file" "$BACKUP_DIR/" && echo "💾 $file"
done

# 6. Копирование файлов
echo ""
echo "[4/6] Копирование..."
mkdir -p "$REPO_DIR/personas" "$REPO_DIR/scenarios" "$REPO_DIR/governance" "$REPO_DIR/core" "$REPO_DIR/visual"

cp "$TMP_DIR/MARINA_MODULE_v1.1.json" "$REPO_DIR/personas/"
echo "   ✅ personas/MARINA_MODULE_v1.1.json"

cp "$TMP_DIR/STATE_TEMPLATE.json" "$REPO_DIR/state/"
echo "   ✅ state/STATE_TEMPLATE.json"

cp "$TMP_DIR/SCENARIO_MATRIX.json" "$REPO_DIR/scenarios/"
echo "   ✅ scenarios/SCENARIO_MATRIX.json"

cp "$TMP_DIR/CORE_PATCH_MARINA.md" "$REPO_DIR/core/"
echo "   ✅ core/CORE_PATCH_MARINA.md"

cp "$TMP_DIR/QWEN_ADAPTER_MARINA.md" "$REPO_DIR/visual/"
echo "   ✅ visual/QWEN_ADAPTER_MARINA.md"

cp "$TMP_DIR/GOVERNANCE_NOTE_MARINA.md" "$REPO_DIR/governance/"
echo "   ✅ governance/GOVERNANCE_NOTE_MARINA.md"

# 7. Валидация JSON
echo ""
echo "[5/6] Валидация JSON..."
python3 -c "
import json, sys
files = [
    ('$REPO_DIR/state/STATE_TEMPLATE.json', 'STATE_TEMPLATE'),
    ('$REPO_DIR/scenarios/SCENARIO_MATRIX.json', 'SCENARIO_MATRIX'),
    ('$REPO_DIR/personas/MARINA_MODULE_v1.1.json', 'MARINA_MODULE')
]
for path, name in files:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            json.load(f)
        print(f'   ✅ {name}')
    except Exception as e:
        print(f'   ❌ {name}: {e}')
        sys.exit(1)
"

# 8. Git commit + push
echo ""
echo "[6/6] Git commit..."
git add -A
git status --short
echo ""
read -p "Подтвердите коммит? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    echo "❌ Коммит отменён. git reset HEAD для отката."
    rm -rf "$TMP_DIR"
    exit 0
fi

git commit -m "feat: add Marina character (MARINA_001) — sunshine pixie

- Add MARINA_MODULE_v1.1.json (anxious-preoccupied, MA1-MA7)
- Update STATE_TEMPLATE.json (20+ marina flags)
- Update SCENARIO_MATRIX.json (8 scenarios: SC_MARINA_001-007 + sauna)
- Add CORE_PATCH_MARINA.md (mnemonics MR, MA1-MA7, MG1-MG3)
- Add QWEN_ADAPTER_MARINA.md (visual prompts)
- Add GOVERNANCE_NOTE_MARINA.md (safety, breaking points)

Psychology: Erikson, Bowlby (anxious-preoccupied), Simon&Gagnon,
Festinger (social comparison), Basson, Perel, NLP

Safety: STOP words, [SAFETY_CHECK] at MA3/MA6, breaking points"

echo "✅ Коммит создан"

echo ""
echo "Push..."
git push origin $(git branch --show-current) && echo "✅ Push выполнен" || echo "⚠️ Push не удался. Проверьте remote."

# Cleanup
rm -rf "$TMP_DIR"

echo ""
echo "========================================"
echo "  ✅ SETUP ЗАВЕРШЁН!"
echo "========================================"
echo ""
echo "📁 Backup: $BACKUP_DIR"
echo "🧠 Персонаж: MARINA_001 (Солнечный зайчик)"
echo "📊 Уровни: MA1-MA7"
echo "🛡️ Safety: СТОП / ХВАТИТ / КРАСНАЯ КАРТОЧКА"
echo ""
echo "🚀 Следующие шаги:"
echo "   1. git log --oneline -3"
echo "   2. cat personas/MARINA_MODULE_v1.1.json"
echo "   3. Начните сценарий: SC_MARINA_001"
echo ""
echo "========================================"
